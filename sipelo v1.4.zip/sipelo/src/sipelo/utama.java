
package sipelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class utama extends javax.swing.JFrame {
    
    koneksi db = new koneksi();
    private static Connection con = null;
    private static Statement st = null;
    private static ResultSet rs = null;
    private String ds = "Dosen";
    private String ms = "Mahasiswa";
    private static String nip;
    private static String nim;
    
    public void setNip(String nip){
        this.nip=nip;
    }
    
    public static String getNip(){
        return nip;
    }
    
    public void setNim(String nim){
        this.nim=nim;
    }
    
    public static String getNim(){
        return nim;
    }
    
    public utama() {
        initComponents();
    }
    
    public void masukkan(String oyi){
        try{
            st = db.getKoneksi().createStatement();
            st.executeUpdate("insert into usession "
                    + "(nomorinduk) " + " values ('"+oyi+"');");
            //JOptionPane.showMessageDialog(null,""
              //      + "Data Berhasil di Simpan");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,""
                    + "Data Gagal di Simpan" +ex);
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        username = new sipelo.CustomTextField();
        password = new sipelo.CustomPasswordField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistem Penugasan Kelompok by Zami, Danun, Aqil");
        setFocusCycleRoot(false);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(144, 180, 211));

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("SISTEM  PENUGASAN  KELOMPOK");

        jLabel2.setFont(new java.awt.Font("Rabbid Highway Sign IV", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("S I P E L O   L O G I N");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        jButton1.setBackground(new java.awt.Color(204, 204, 255));
        jButton1.setText("MASUK");
        jButton1.setBorder(null);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setOpaque(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        username.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        username.setColumns(1);
        username.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        username.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        username.setPlaceholder("Masukkan Username");
        username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameActionPerformed(evt);
            }
        });

        password.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        password.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        password.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon("G:\\KULIAH\\3\\pemrograman berbasis objek\\proggress\\Proyek PBO\\100.png")); // NOI18N
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(188, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGap(25, 25, 25)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(password, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(189, 189, 189))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(616, 383));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         db.koneksiDatabase();
        try {
            String sql = "SELECT * FROM pengguna WHERE nomorinduk = '" + username.getText() + "' AND password = '" + password.getText() + "'";
            st = db.getKoneksi().createStatement();
            ResultSet rsLogin = st.executeQuery(sql);

            rsLogin.next();
            rsLogin.last(); //mengecek jumlah baris pada hasil query
            if (rsLogin.getRow()==1){
                //JOptionPane.showMessageDialog(null, "Login Berhasil!");
                if (ds.equals(rsLogin.getString("kategori"))){
                    //String dsn = "SELECT * FROM dosen WHERE nip = '" + rsLogin.getString("nomorinduk") + "'";
                    //st = db.getKoneksi().createStatement();
                    //ResultSet rsDosen = st.executeQuery(dsn);
                setNip(rsLogin.getString("nomorinduk"));
                masukkan(getNip());
                
                try{
                com.jtattoo.plaf.aluminium.AluminiumLookAndFeel.setTheme("Large-Font", "Java Swing", "");
                UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
                //alamat frame yang ingin dituju
                new dosen().setVisible(true); //<-- BILA MAU DIARAHKAN KE Frame Menu Utama
                this.dispose();
                //alamat frame yang ingin dituju
                }catch (Exception ex) 
                {
                    ex.printStackTrace();
                }
                }
                 
                if (ms.equals(rsLogin.getString("kategori"))){
                    //String mhsw = "SELECT * FROM mhs WHERE nim = '" + rsLogin.getString("nomorinduk") + "'";
                    //st = db.getKoneksi().createStatement();
                    //ResultSet rsMhs = st.executeQuery(mhsw);
                setNim(rsLogin.getString("nomorinduk"));
                masukkan(getNim());
                try{
                com.jtattoo.plaf.aluminium.AluminiumLookAndFeel.setTheme("Large-Font", "Java Swing", "");
                UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
                //alamat frame yang ingin dituju
                new mahasiswa().setVisible(true); //<-- BILA MAU DIARAHKAN KE Frame Menu Utama
                this.dispose();
                //alamat frame yang ingin dituju
                }catch (Exception ex) 
                {
                ex.printStackTrace();
                }
            } 
         }else {
                JOptionPane.showMessageDialog(null, "Maaf, Username / Password salah!");
                password.setText("");
                password.requestFocus();
            }
          }catch (SQLException e) {
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try
            {
                com.jtattoo.plaf.aluminium.AluminiumLookAndFeel.setTheme("Large-Font", "Java Swing", "");
                UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
                
                java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new utama().setVisible(true);
            }
        });
            } 
          catch (Exception ex) 
            {
                ex.printStackTrace();
            }//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(utama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private sipelo.CustomPasswordField password;
    private sipelo.CustomTextField username;
    // End of variables declaration//GEN-END:variables
}
