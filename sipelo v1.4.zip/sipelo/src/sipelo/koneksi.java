package sipelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.JOptionPane;
 
/**
 *
 * @author www.kangsunu.web.id
 *
 * MORE JAVA BASIC TUTORIAL VISIT: http://www.kangsunu.web.id/
 */

public class koneksi {
 
    private static Connection koneksi = null;
    private static ResultSet rs = null;
    private static Statement st = null;
    PreparedStatement ps = null;
 
    public Connection getKoneksi() {
        return koneksi;
    }
 
    public void koneksiDatabase() { //<-- untuk koneksi ke database
        // Cek Driver
        try {
            Class.forName("com.mysql.jdbc.Driver"); //<-- nama driver untuk koneksi ke MySQL
 
            // Cek Database
            try {
                String url, user, password;
                url = "jdbc:mysql://localhost:3306/sipelo"; //alamat DB
                user = "root";
                password = "";
                koneksi = DriverManager.getConnection(url, user, password);
 
                System.out.println("Koneksi Sukses");
            } catch (SQLException se) {
                JOptionPane.showMessageDialog(null, "Koneksi Gagal! " + se);
                System.exit(0);
            }
        } catch (ClassNotFoundException cnfe) {
            JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan! \n" + cnfe);
            System.exit(0);
        }
    }
 
    public void simpanKelompok(String no, String ketua, String A1, String A2, String A3, String A4){        
        try{
            String nimk = null;
            String sql = "SELECT * FROM mhs WHERE namamhs = '"+ ketua +"';";
            st = koneksi.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                nimk = rs.getString("nim");
            }
            st.executeUpdate("insert into pengguna (nomorinduk,password,kategori) values ('"+nimk+"','"+nimk+"','Mahasiswa');");
            st.executeUpdate("insert into kelompok (no_kelompok,nim,namamhs) values ('"+no+"','"+nimk+"','"+ketua+"');");
            
            String nima1 = null;
            String a1 = "SELECT * FROM mhs WHERE namamhs = '"+ A1 +"';";
            st = koneksi.createStatement();
            ResultSet rsa1 = st.executeQuery(a1);
            while(rsa1.next()){
                nima1 = rsa1.getString("nim");
            }
            st.executeUpdate("insert into kelompok (no_kelompok,nim,namamhs) values ('"+no+"','"+nima1+"','"+A1+"');");
            
            String nima2 = null;
            String a2 = "SELECT * FROM mhs WHERE namamhs = '"+ A2 +"';";
            st = koneksi.createStatement();
            ResultSet rsa2 = st.executeQuery(a2);
            while(rsa2.next()){
                nima2 = rsa2.getString("nim");
            }
            st.executeUpdate("insert into kelompok (no_kelompok,nim,namamhs) values ('"+no+"','"+nima2+"','"+A2+"');");
            
            String nima3 = null;
            String a3 = "SELECT * FROM mhs WHERE namamhs = '"+ A3 +"';";
            st = koneksi.createStatement();
            ResultSet rsa3 = st.executeQuery(a3);
            while(rsa3.next()){
                nima3 = rsa3.getString("nim");
            }
            st.executeUpdate("insert into kelompok (no_kelompok,nim,namamhs) values ('"+no+"','"+nima3+"','"+A3+"');");
            
            String nima4 = null;
            String a4 = "SELECT * FROM mhs WHERE namamhs = '"+ A4 +"';";
            st = koneksi.createStatement();
            ResultSet rsa4 = st.executeQuery(a4);
            while(rsa4.next()){
                nima4 = rsa4.getString("nim");
            }
            st.executeUpdate("insert into kelompok (no_kelompok,nim,namamhs) values ('"+no+"','"+nima4+"','"+A4+"');");
            JOptionPane.showMessageDialog(null,"Data Berhasil di Simpan");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Mahasiswa tersebut sudah ada di kelompok lain!");
        }
    }
    
    public void simpanTugas(String nom, String soal, String K1, String K2, String K3, String K4){
        try{
            
            SimpleDateFormat sdfdate = new SimpleDateFormat("yyyy-MM-dd");
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE,7);
            java.util.Date seminggulagi = cal.getTime();
            
            String matkul = null;
            String aktif = "select * from dosen where nip = (select nomorinduk from usession);";
            st = koneksi.createStatement();
            rs = st.executeQuery(aktif);
            while(rs.next()){
                matkul = rs.getString("matakuliah");
            }
            Statement sta = koneksi.createStatement();
            sta.executeUpdate("insert into tugas (no_kelompok,deskripsi,batas_waktu,matkul,kunci1,kunci2,kunci3,kunci4) " + " values ('"+nom+"','"+soal+"','"+sdfdate.format(seminggulagi)+"','"+matkul+"','"+K1+"','"+K2+"','"+K3+"','"+K4+"');");
            JOptionPane.showMessageDialog(null,"Data Berhasil di Simpan");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Data Sudah Ada!");
        }
    }
    
    public ResultSet soal(String s){
        try{
            ps = koneksi.prepareStatement("select * from tugas where no_kelompok = ?");
            ps.setString(1, s);
            rs = ps.executeQuery();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
        return rs;
    }
    
    public ResultSet tampilkan(String nomor){
        try{            
            Statement st = koneksi.createStatement();
            ps = koneksi.prepareStatement("select no, soal, jawaban from uas where kodeuas = ?");
            ps.setString(1, nomor);
            rs = ps.executeQuery();
            JOptionPane.showMessageDialog(null,"Data Berhasil di Simpan");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Data Gagal di Simpan");
        }
        return rs;
    }
    
    public void hitung(String kelompok){
    try{
            int k1=0;
            int k2=0;
            int k3=0;
            int k4=0;
            
            String kunci1 = " ";
            String kunci2 = " ";
            String kunci3 = " ";
            String kunci4 = " ";
            String nimm = " ";          

            String query = "SELECT * FROM tugas where no_kelompok='"+kelompok+"';";
            st = koneksi.createStatement();
            rs = st.executeQuery(query);
            while(rs.next()){
                kunci1 = rs.getString("kunci1");
                kunci2 = rs.getString("kunci2");
                kunci3 = rs.getString("kunci3");
                kunci4 = rs.getString("kunci4");
            }

	String querii = "SELECT * FROM kelompok k inner join pengguna p on k.nim=p.nomorinduk where no_kelompok='"+kelompok+"';";
            st = koneksi.createStatement();
            rs = st.executeQuery(querii);
            while(rs.next()){
                nimm = rs.getString("nim");
            }	
            
            String jawab = " ";
            String queri = "SELECT * FROM hasiltugas WHERE nim = '"+nimm+"';";
            st = koneksi.createStatement();
            rs = st.executeQuery(queri);
            while(rs.next()){
                jawab = rs.getString("jawaban");
            }
            
            String[] kata = jawab.split(" ") ;
            String[] penampung = new String[kata.length];
            
            for (int counter = 0; counter<kata.length; counter++){
                penampung[counter]=kata[counter];
            }
            
            for (int counter = 0; counter<kata.length; counter++){
                if(penampung[counter].equals(kunci1)){
                    k1=1;
                }
                if(penampung[counter].equals(kunci2)){
                    k2=1;
                }
                if(penampung[counter].equals(kunci3)){
                    k3=1;
                }
                if(penampung[counter].equals(kunci4)){
                    k4=1;
                }
            }
            int total=k1+k2+k3+k4;
            
            st = koneksi.createStatement();
            st.executeUpdate("insert into penilaian (nim,nilai) " + " values ('"+nimm+"','"+total+"');");
            JOptionPane.showMessageDialog(null,"Data di Simpan");
        } catch(Exception e){
            JOptionPane.showMessageDialog(null,"Data Gagal di Simpan" +e);
        }
    }
    
    public static void main(String[] kon) {
        new koneksi().koneksiDatabase();
    }
}